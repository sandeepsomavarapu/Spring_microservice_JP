package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepo;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;
	@Override
	public String addProduct(Product product) {
		return repo.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {
		
		return repo.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {
		
		return repo.deleteProduct(productId);
	}

	@Override
	public Product getProductById(int productId) {
		
		return repo.getProductById(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		
		return repo.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {
		
		return repo.getAllProductsBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {
		
		return repo.getAllProductsByCategory(productCategory);
	}

}
