package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.exceptions.ProductNotFound;
import com.example.demo.service.ProductService;

//{
//    "productId": 1,
//    "productName": "samasung",
//    "productPrice": 9000,
//    "productCategory": "electronics"
//}
@RestController // @Controller+@RsponseBody
@RequestMapping(value="/products",produces = "application/xml") // http://localhost:9999/products
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping(value="/addproduct",consumes = "application/xml") // http://localhost:9999/products/addproduct
	public String insertProduct(@RequestBody @Validated Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateproduct") // http://localhost:9999/products/updateproduct
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/remove/{pid}") // http://localhost:9999/products/remove/1
	public String deleteProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);
	}
	@GetMapping("/getById/{pid}") // http://localhost:9999/products/getById/1
	public Product getProduct(@PathVariable("pid") int productId) throws ProductNotFound {
		return service.getProductById(productId);
	}

	@GetMapping("/getproducts") // http://localhost:9999/products/getProducts
	public List<Product> getProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/getbetween/{price1}/{price2}") // http://localhost:9999/products/getbetween/2000/5000
	public List<Product> getAllProductsBetween(@PathVariable("price1") int intialPrice,
			@PathVariable("price2") int finalPrice) {
		return service.getAllProductsBetween(intialPrice, finalPrice);
	}

	@GetMapping("/getproducts/{category}") // http://localhost:9999/products/getproducts/electronics
	public List<Product> getProductsByCategory(@PathVariable("category") String productCategory) {
		return service.getAllProductsByCategory(productCategory);
	}
//	@ExceptionHandler(ProductNotFound.class)
//	@ResponseStatus(reason = "Product Id Is Invalid")
//	public void handlerException()
//	{
//		
//		
//	}

}
