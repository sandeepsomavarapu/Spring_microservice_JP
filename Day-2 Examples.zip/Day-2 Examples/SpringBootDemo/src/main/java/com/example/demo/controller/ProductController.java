package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // @Controller+@RsponseBody
@RequestMapping("products") // http://localhost:9999/products
public class ProductController {
	List<Product> products = new ArrayList<>();

	public ProductController() {
		products.add(new Product(1, "samsung", 34567, "electronics"));
		products.add(new Product(2, "toordal", 3900, "grocories"));
		products.add(new Product(3, "tiger", 45000, "toys"));
		products.add(new Product(5, "dell", 55000, "electronics"));
		products.add(new Product(4, "lion", 4500, "toys"));

	}

	@GetMapping("/msg")
	public String getMessage() {
		return "Leave Us Feeling Hungry";
	}

	@GetMapping("/getproducts")
	public List<Product> getProducts() {
		return products;
	}
}
